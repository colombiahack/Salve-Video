package com.savetools.app

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance

data class ThemeSettings(val mode: Int = 0, val accent: Int = 0) // mode: 0 sistema, 1 claro, 2 oscuro

object Palette {
    val accents = listOf(
        "Negro" to Color(0xFF111111),
        "Verde" to Color(0xFF2EA44F),
        "Azul" to Color(0xFF1A73E8),
        "Morado" to Color(0xFF7C4DFF),
        "Naranja" to Color(0xFFE65100)
    )
}

fun buildScheme(accent: Color, dark: Boolean): ColorScheme {
    return if (!dark) {
        val tint = lerp(accent, Color.White, 0.85f)
        val deep = lerp(accent, Color.Black, 0.35f)
        lightColorScheme(
            primary = accent, onPrimary = Color.White,
            primaryContainer = tint, onPrimaryContainer = deep,
            secondaryContainer = tint, onSecondaryContainer = deep,
            background = Color(0xFFFAFAFA), onBackground = Color(0xFF111111),
            surface = Color.White, onSurface = Color(0xFF111111),
            surfaceVariant = Color(0xFFEFEFEF), onSurfaceVariant = Color(0xFF666666),
            outline = Color(0xFFBBBBBB), outlineVariant = Color(0xFFDDDDDD)
        )
    } else {
        val veryDark = accent.luminance() < 0.15f
        val p = if (veryDark) Color.White else lerp(accent, Color.White, 0.3f)
        val onP = if (p.luminance() > 0.5f) Color(0xFF111111) else Color.White
        val cont = if (veryDark) Color(0xFF2E2E31) else lerp(accent, Color.Black, 0.55f)
        darkColorScheme(
            primary = p, onPrimary = onP,
            primaryContainer = cont, onPrimaryContainer = Color.White,
            secondaryContainer = cont, onSecondaryContainer = Color.White,
            background = Color(0xFF0F0F10), onBackground = Color(0xFFEDEDED),
            surface = Color(0xFF1B1B1D), onSurface = Color(0xFFEDEDED),
            surfaceVariant = Color(0xFF2A2A2D), onSurfaceVariant = Color(0xFFA0A0A5),
            outline = Color(0xFF55555A), outlineVariant = Color(0xFF3A3A3E)
        )
    }
}
