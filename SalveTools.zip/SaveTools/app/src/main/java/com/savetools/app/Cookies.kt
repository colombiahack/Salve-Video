package com.savetools.app

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import java.io.File

object Cookies {

    enum class Service(
        val id: String,
        val label: String,
        val desc: String,
        val loginUrl: String,
        val cookieUrls: List<String>,
        val hosts: List<String>
    ) {
        YOUTUBE(
            "youtube", "YouTube", "Privados o con restricción de edad",
            "https://accounts.google.com/ServiceLogin?service=youtube&continue=https://www.youtube.com/",
            listOf("https://www.youtube.com", "https://accounts.google.com", "https://www.google.com"),
            listOf("youtube.com", "youtu.be")
        ),
        INSTAGRAM(
            "instagram", "Instagram", "Reels, historias y publicaciones",
            "https://www.instagram.com/accounts/login/",
            listOf("https://www.instagram.com"),
            listOf("instagram.com")
        ),
        FACEBOOK(
            "facebook", "Facebook", "Grupos y perfiles privados",
            "https://m.facebook.com/login",
            listOf("https://www.facebook.com", "https://m.facebook.com"),
            listOf("facebook.com", "fb.watch")
        ),
        X(
            "x", "X / Twitter", "Videos marcados como sensibles",
            "https://x.com/i/flow/login",
            listOf("https://x.com", "https://twitter.com"),
            listOf("x.com", "twitter.com")
        )
    }

    fun file(ctx: Context, id: String) = File(ctx.filesDir, "cookies_$id.txt")
    fun importFile(ctx: Context) = File(ctx.filesDir, "cookies_import.txt")

    /** Archivo de cookies que corresponde a una URL (cuenta conectada o cookies.txt importado). */
    fun forUrl(ctx: Context, url: String): File? {
        val host = Uri.parse(url).host?.lowercase() ?: return null
        val service = Service.values().firstOrNull { s ->
            s.hosts.any { host == it || host.endsWith(".$it") }
        }
        val own = service?.let { file(ctx, it.id) }?.takeIf { it.exists() }
        return own ?: importFile(ctx).takeIf { it.exists() }
    }

    /** Guarda en formato Netscape las cookies que dejó el inicio de sesión en el WebView. */
    fun saveFromWebView(ctx: Context, s: Service): Int {
        val cm = CookieManager.getInstance()
        cm.flush()
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        var n = 0
        for (u in s.cookieUrls) {
            val raw = cm.getCookie(u) ?: continue
            val host = Uri.parse(u).host ?: continue
            val domain = "." + host.split(".").takeLast(2).joinToString(".")
            for (pair in raw.split(";")) {
                val idx = pair.indexOf('=')
                if (idx <= 0) continue
                val name = pair.substring(0, idx).trim()
                val value = pair.substring(idx + 1).trim()
                sb.append("$domain\tTRUE\t/\tTRUE\t2147483647\t$name\t$value\n")
                n++
            }
        }
        if (n > 0) file(ctx, s.id).writeText(sb.toString())
        return n
    }
}
