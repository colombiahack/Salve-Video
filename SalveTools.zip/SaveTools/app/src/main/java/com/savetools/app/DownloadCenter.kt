package com.savetools.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Cola de descargas a nivel de proceso: sigue viva aunque se cierre la pantalla,
 * se guarda en disco y se reanuda sola (los archivos .part se conservan).
 */
object DownloadCenter {

    private const val NET_MSG = "Sin conexión. Se reanudará sola cuando vuelva."

    private lateinit var app: Application
    private var started = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private val _history = MutableStateFlow<List<HistoryEntry>>(emptyList())
    val history: StateFlow<List<HistoryEntry>> = _history.asStateFlow()

    private val mutex = Mutex()                       // una descarga a la vez
    private val jobs = ConcurrentHashMap<Long, Job>()
    private val cancelled: MutableSet<Long> = Collections.synchronizedSet(mutableSetOf())
    private val nextId = AtomicLong(1)

    @Synchronized
    fun init(application: Application) {
        if (started) return
        started = true
        app = application
        _history.value = History.load(app)
        restore()
        registerNetworkCallback()
    }

    // ---------- Persistencia ----------
    private fun restore() {
        val raw = app.getSharedPreferences("queue", Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
        val list = try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val saved = o.optString("status", "READY")
                if (saved == "DONE") return@mapNotNull null
                val status = when (saved) {
                    "DOWNLOADING", "QUEUED", "WAITING" -> Status.WAITING
                    "ERROR" -> Status.ERROR
                    else -> Status.READY
                }
                DownloadItem(
                    id = o.getLong("id"),
                    url = o.getString("url"),
                    title = o.optString("title").takeIf { it.isNotEmpty() },
                    thumbnail = o.optString("thumbnail").takeIf { it.isNotEmpty() },
                    durationSec = o.optInt("duration", -1).takeIf { it >= 0 },
                    maxHeight = o.optInt("maxHeight", -1).takeIf { it > 0 },
                    quality = runCatching { Quality.valueOf(o.optString("quality", "BEST")) }
                        .getOrDefault(Quality.BEST),
                    selected = o.optBoolean("selected", true),
                    status = status,
                    message = when (status) {
                        Status.WAITING -> "Interrumpida. Se reanuda al abrir la app."
                        Status.ERROR -> o.optString("message")
                        else -> ""
                    }
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
        _items.value = list
        nextId.set((list.maxOfOrNull { it.id } ?: 0L) + 1)

        // Borra parciales de elementos que ya no existen
        val keep = list.map { it.id.toString() }.toSet()
        File(app.filesDir, "partial").listFiles()?.forEach { if (it.name !in keep) it.deleteRecursively() }
    }

    private fun persist() {
        val arr = JSONArray()
        _items.value.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("url", it.url)
                    .put("title", it.title ?: "").put("thumbnail", it.thumbnail ?: "")
                    .put("duration", it.durationSec ?: -1).put("maxHeight", it.maxHeight ?: -1)
                    .put("quality", it.quality.name).put("selected", it.selected)
                    .put("status", it.status.name)
                    .put("message", if (it.status == Status.ERROR) it.message else "")
            )
        }
        app.getSharedPreferences("queue", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }

    private fun mutate(id: Long, save: Boolean = true, f: (DownloadItem) -> DownloadItem) {
        _items.update { l -> l.map { if (it.id == id) f(it) else it } }
        if (save) persist()
    }

    private fun progress(id: Long, p: Float) = mutate(id, false) { it.copy(progress = p) }

    // ---------- Enlaces ----------
    fun addLinks(text: String): Int {
        val links = Regex("https?://\\S+").findAll(text)
            .map { it.value.trimEnd(',', ')', '.') }.distinct().toList()
        val existing = _items.value.map { it.url }.toSet()
        val fresh = links.filter { it !in existing }
            .map { DownloadItem(id = nextId.getAndIncrement(), url = it) }
        if (fresh.isEmpty()) return 0
        _items.update { fresh + it }
        persist()
        fresh.forEach { fetchInfo(it) }
        return fresh.size
    }

    private fun fetchInfo(item: DownloadItem) {
        scope.launch {
            try {
                val req = YoutubeDLRequest(item.url).apply {
                    addOption("--no-playlist")
                    addOption("--print", "%(title)s|||%(duration)s|||%(thumbnail)s|||%(height)s")
                    applyCookies(this, item.url)
                }
                val out = YoutubeDL.getInstance().execute(req).out
                val line = out.lineSequence().firstOrNull { it.contains("|||") } ?: return@launch
                val p = line.split("|||")
                fun v(i: Int) = p.getOrNull(i)?.trim()?.takeIf { it.isNotEmpty() && it != "NA" && it != "None" }
                mutate(item.id) {
                    it.copy(
                        title = v(0),
                        durationSec = v(1)?.toDoubleOrNull()?.toInt(),
                        thumbnail = v(2),
                        maxHeight = v(3)?.toDoubleOrNull()?.toInt()
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    // ---------- Selección y calidad ----------
    fun setQuality(id: Long, q: Quality) = mutate(id) { it.copy(quality = q) }

    fun toggleSelected(id: Long) = mutate(id) { it.copy(selected = !it.selected) }

    fun selectAll(sel: Boolean) {
        _items.update { l -> l.map { it.copy(selected = sel) } }
        persist()
    }

    fun toggleSelectAll() = selectAll(!_items.value.all { it.selected })

    fun setQualityForSelected(q: Quality) {
        _items.update { l ->
            l.map {
                val busy = it.status == Status.DOWNLOADING || it.status == Status.QUEUED
                if (it.selected && !busy) it.copy(quality = q) else it
            }
        }
        persist()
    }

    fun remove(id: Long) {
        cancel(id)
        _items.update { l -> l.filter { it.id != id } }
        File(app.filesDir, "partial/$id").deleteRecursively()
        persist()
    }

    // ---------- Descarga ----------
    fun download(id: Long) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        if (item.status == Status.DOWNLOADING || item.status == Status.QUEUED) return
        cancelled.remove(id)
        mutate(id) { it.copy(status = Status.QUEUED, progress = 0f, message = "En cola") }
        startService()
        jobs[id] = scope.launch { mutex.withLock { runDownload(id) } }
    }

    fun downloadSelected() {
        _items.value
            .filter { it.selected && (it.status == Status.READY || it.status == Status.ERROR || it.status == Status.WAITING) }
            .forEach { download(it.id) }
    }

    /** Reanuda lo que quedó interrumpido al cerrarse la app. */
    fun resumeInterrupted() {
        _items.value.filter { it.status == Status.WAITING }.forEach { download(it.id) }
    }

    fun cancel(id: Long) {
        cancelled.add(id)
        try { YoutubeDL.getInstance().destroyProcessById("dl-$id") } catch (_: Exception) {}
        jobs.remove(id)?.cancel()
        mutate(id) {
            if (it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.WAITING)
                it.copy(status = Status.READY, progress = 0f, message = "Cancelado. Puedes reanudarla.")
            else it
        }
    }

    fun cancelAll() {
        _items.value
            .filter { it.status == Status.DOWNLOADING || it.status == Status.QUEUED }
            .forEach { cancel(it.id) }
    }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))
        } catch (_: Exception) {
            // Si Android no permite iniciarlo en segundo plano, la descarga sigue mientras el proceso viva.
        }
    }

    private fun runDownload(id: Long) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        mutate(id) { it.copy(status = Status.DOWNLOADING, message = "Descargando…") }
        // Carpeta estable: conserva los .part para poder reanudar
        val dir = File(app.filesDir, "partial/$id").apply { mkdirs() }
        try {
            val req = YoutubeDLRequest(item.url).apply {
                addOption("--no-playlist")
                addOption("--continue")
                addOption("--retries", "10")
                addOption("--fragment-retries", "10")
                addOption("--socket-timeout", "30")
                addOption("-o", "${dir.absolutePath}/%(title).100s.%(ext)s")
                applyFormat(this, item.quality)
                applyCookies(this, item.url)
            }
            YoutubeDL.getInstance().execute(req, "dl-$id") { p, _, _ ->
                progress(id, (p / 100f).coerceIn(0f, 1f))
            }

            val file = dir.listFiles()
                ?.filter {
                    it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") &&
                        !Regex("\\.f\\d+\\.").containsMatchIn(it.name)
                }
                ?.maxByOrNull { it.length() }
            if (file == null) {
                mutate(id) { it.copy(status = Status.ERROR, message = "No se generó ningún archivo") }
                return
            }
            mutate(id) { it.copy(message = "Guardando…") }

            val size = file.length()
            val saved = MediaSaver.save(app, file)
            if (saved == null) {
                mutate(id) { it.copy(status = Status.ERROR, message = "No se pudo guardar el archivo") }
            } else {
                val duration = if (saved.kind != "image") MediaInfo.durationMs(file) else 0L
                val av1 = saved.kind == "video" && MediaInfo.isAv1(file)
                History.add(
                    app,
                    HistoryEntry(
                        file.nameWithoutExtension, saved.uri.toString(), saved.mime,
                        System.currentTimeMillis(), size, duration, av1
                    )
                )
                _history.value = History.load(app)
                dir.deleteRecursively()
                mutate(id) {
                    it.copy(
                        status = Status.DONE, progress = 1f, selected = false,
                        message = "Guardado en ${saved.folderLabel}"
                    )
                }
            }
        } catch (e: Exception) {
            if (id in cancelled) {
                cancelled.remove(id)
            } else {
                val full = e.message ?: ""
                if (isNetworkError(full)) {
                    mutate(id) { it.copy(status = Status.WAITING, message = NET_MSG) }
                } else {
                    val msg = full.lineSequence().lastOrNull { it.isNotBlank() }?.take(160) ?: "Error"
                    mutate(id) { it.copy(status = Status.ERROR, message = msg) }
                }
            }
        } finally {
            jobs.remove(id)
        }
    }

    private fun isNetworkError(msg: String): Boolean {
        val m = msg.lowercase()
        if ("http error 4" in m) return false
        return listOf(
            "timed out", "timeout", "connection", "network is unreachable", "temporary failure",
            "name resolution", "getaddrinfo", "unable to download", "remote end closed",
            "errno 7", "errno 101", "errno 104", "eof occurred", "incomplete read"
        ).any { it in m }
    }

    /** Cuando vuelve la conexión, retoma lo que se quedó esperando. */
    private fun registerNetworkCallback() {
        try {
            val cm = app.getSystemService(ConnectivityManager::class.java) ?: return
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    _items.value
                        .filter { it.status == Status.WAITING && it.message == NET_MSG }
                        .forEach { download(it.id) }
                }
            })
        } catch (_: Exception) {
        }
    }

    /** "Mejor" = mayor resolución; a igual resolución prefiere H.264 (evita AV1 lento). */
    private fun applyFormat(r: YoutubeDLRequest, q: Quality) {
        when (q) {
            Quality.AUDIO -> {
                r.addOption("-f", "bestaudio/best")
                r.addOption("-x")
                r.addOption("--audio-format", "mp3")
            }
            Quality.BEST -> {
                r.addOption("-f", "bv*+ba/b")
                r.addOption("-S", "res,vcodec:h264,acodec:m4a")
                r.addOption("--merge-output-format", "mp4")
            }
            else -> {
                val h = q.height
                r.addOption("-f", "bv*+ba/b")
                r.addOption("-S", "res:$h,vcodec:h264,acodec:m4a")
                r.addOption("--merge-output-format", "mp4")
            }
        }
    }

    private fun applyCookies(r: YoutubeDLRequest, url: String) {
        Cookies.forUrl(app, url)?.let { r.addOption("--cookies", it.absolutePath) }
    }

    // ---------- Historial ----------
    fun refreshHistory() {
        scope.launch { _history.value = History.prune(app) }
    }

    fun deleteEntry(e: HistoryEntry) {
        scope.launch {
            try { app.contentResolver.delete(Uri.parse(e.uri), null, null) } catch (_: Exception) {}
            History.remove(app, e.uri)
            _history.value = History.load(app)
        }
    }

    fun clearHistory() {
        History.clear(app)
        _history.value = emptyList()
    }
}
