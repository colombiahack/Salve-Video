@file:OptIn(ExperimentalMaterial3Api::class)

package com.savetools.app

import android.content.ContentUris
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Warn = Color(0xFFB26A00)

@Composable
fun AppRoot(
    vm: DownloadViewModel,
    onLogin: (Cookies.Service) -> Unit,
    onImport: () -> Unit,
    onOpen: (HistoryEntry) -> Unit,
    onShare: (HistoryEntry) -> Unit
) {
    val theme by vm.theme.collectAsStateWithLifecycle()
    val dark = when (theme.mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val accent = Palette.accents[theme.accent.coerceIn(0, Palette.accents.lastIndex)].second
    var screen by rememberSaveable { mutableStateOf("home") }
    BackHandler(enabled = screen != "home") { screen = "home" }

    MaterialTheme(colorScheme = buildScheme(accent, dark)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (screen == "home") {
                HomeScreen(vm, onLogin, onImport) { screen = "downloads" }
            } else {
                DownloadsScreen(vm, onOpen, onShare) { screen = "home" }
            }
        }
    }
}

// =====================================================  INICIO
@Composable
fun HomeScreen(
    vm: DownloadViewModel,
    onLogin: (Cookies.Service) -> Unit,
    onImport: () -> Unit,
    onDownloads: () -> Unit
) {
    val queue by vm.items.collectAsStateWithLifecycle()
    val connected by vm.connected.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val theme by vm.theme.collectAsStateWithLifecycle()
    var text by rememberSaveable { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme

    LazyColumn(
        modifier = Modifier.fillMaxSize().systemBarsPadding(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                FilledTonalButton(onClick = onDownloads) { Text("Mis descargas") }
            }
            Spacer(Modifier.height(4.dp))
            Text("Agrega links, elige calidad y descarga.", color = cs.onSurfaceVariant)
        }

        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                OutlinedCard(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.outlinedCardColors(containerColor = cs.surface),
                    modifier = Modifier.fillMaxWidth(0.88f)
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = text,
                            onValueChange = { text = it },
                            placeholder = {
                                Text("Enlaces (uno por línea)", style = MaterialTheme.typography.bodyMedium)
                            },
                            textStyle = MaterialTheme.typography.bodyMedium,
                            minLines = 2,
                            maxLines = 4,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "TikTok, YouTube, Instagram, X, Facebook y más",
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = {
                                    clipboard.getText()?.text?.let {
                                        text = if (text.isBlank()) it else text + "\n" + it
                                    }
                                },
                                modifier = Modifier.weight(1f).height(42.dp)
                            ) { Text("Pegar") }
                            Button(
                                onClick = { vm.addLinks(text); text = "" },
                                modifier = Modifier.weight(1.3f).height(42.dp)
                            ) { Text("+  Agregar", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }

        if (queue.isEmpty()) {
            item {
                Text(
                    "Pega uno o varios enlaces y toca Agregar.\nAquí aparecen para que elijas la calidad.",
                    color = cs.onSurfaceVariant, modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("En la lista (${queue.size})", fontWeight = FontWeight.SemiBold)
                    Button(onClick = vm::downloadAll) { Text("Descargar todo") }
                }
            }
            items(queue, key = { it.id }) { ItemCard(it, vm) }
        }

        // ---- Cuentas
        item {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant)
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Cuentas", style = MaterialTheme.typography.titleLarge)
                    Text("Opcional. Solo para videos que piden iniciar sesión.", color = cs.onSurfaceVariant)
                    Cookies.Service.values().forEach { s ->
                        val on = s.id in connected
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(s.label, fontWeight = FontWeight.Medium)
                                Text(
                                    if (on) "Conectado" else s.desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (on) Color(0xFF2EA44F) else cs.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { if (on) vm.disconnect(s) else onLogin(s) }) {
                                Text(if (on) "Desconectar" else "Conectar")
                            }
                        }
                    }
                    TextButton(onClick = onImport) {
                        Text(if ("import" in connected) "cookies.txt importado (cambiar)" else "Importar cookies.txt")
                    }
                    if (notice.isNotBlank()) Text(notice, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = vm::updateEngine) { Text("Actualizar motor de descarga") }
                }
            }
        }

        // ---- Apariencia
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant),
                    modifier = Modifier.fillMaxWidth(0.88f)
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Apariencia", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Sistema", "Claro", "Oscuro").forEachIndexed { i, label ->
                                FilterChip(
                                    selected = theme.mode == i,
                                    onClick = { vm.setThemeMode(i) },
                                    label = { Text(label, style = MaterialTheme.typography.labelMedium) }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Palette.accents.forEachIndexed { i, (_, c) ->
                                val selected = theme.accent == i
                                Box(
                                    Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(c)
                                        .border(
                                            if (selected) 3.dp else 1.dp,
                                            if (selected) cs.onSurface else cs.outline,
                                            CircleShape
                                        )
                                        .clickable { vm.setAccent(i) }
                                )
                            }
                        }
                        Text(
                            Palette.accents[theme.accent.coerceIn(0, Palette.accents.lastIndex)].first,
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Text(
                "Descarga solo contenido sobre el que tengas derecho.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ItemCard(item: DownloadItem, vm: DownloadViewModel) {
    val cs = MaterialTheme.colorScheme
    val busy = item.status == Status.DOWNLOADING || item.status == Status.QUEUED
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                item.title ?: item.url, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            if (item.title != null) {
                Text(
                    item.url, style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Quality.values().forEach { q ->
                    FilterChip(
                        selected = item.quality == q,
                        onClick = { vm.setQuality(item.id, q) },
                        enabled = !busy,
                        label = { Text(q.label) }
                    )
                }
            }
            if (item.status == Status.DOWNLOADING) {
                LinearProgressIndicator(progress = { item.progress }, modifier = Modifier.fillMaxWidth())
            }
            if (item.message.isNotBlank()) {
                Text(
                    item.message, style = MaterialTheme.typography.bodySmall,
                    color = if (item.status == Status.ERROR) cs.error else cs.onSurfaceVariant
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (busy) {
                    OutlinedButton(onClick = { vm.cancel(item.id) }) { Text("Cancelar") }
                } else {
                    Button(onClick = { vm.download(item.id) }) {
                        Text(if (item.status == Status.DONE) "Descargar otra vez" else "Descargar")
                    }
                }
                TextButton(onClick = { vm.remove(item.id) }) { Text("Quitar") }
            }
        }
    }
}

// =====================================================  MIS DESCARGAS
@Composable
fun DownloadsScreen(
    vm: DownloadViewModel,
    onOpen: (HistoryEntry) -> Unit,
    onShare: (HistoryEntry) -> Unit,
    onBack: () -> Unit
) {
    val history by vm.history.collectAsStateWithLifecycle()
    var filter by rememberSaveable { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    LaunchedEffect(Unit) { vm.refreshHistory() }

    val shown = history.filter {
        when (filter) {
            1 -> it.kind == "video"
            2 -> it.kind == "audio"
            3 -> it.kind == "image"
            else -> true
        }
    }
    val count = if (shown.size == 1) "1 archivo" else "${shown.size} archivos"

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Text("←", fontSize = 26.sp) }
            Column(Modifier.weight(1f)) {
                Text("Mis descargas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "$count · ${formatSize(shown.sumOf { it.size })}",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Box {
                IconButton(onClick = { menu = true }) { Text("⋮", fontSize = 26.sp) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Borrar historial") },
                        onClick = { menu = false; vm.clearHistory() }
                    )
                }
            }
        }

        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Todo", "Videos", "Audio", "Fotos").forEachIndexed { i, label ->
                FilterChip(
                    selected = filter == i,
                    onClick = { filter = i },
                    label = { Text(label) }
                )
            }
        }

        if (shown.isEmpty()) {
            Text(
                "Aquí aparecerá lo que descargues.",
                color = cs.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                textAlign = TextAlign.Center
            )
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.uri }) { e ->
                    HistoryRow(e, onOpen, onShare) { vm.deleteEntry(e) }
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(
    e: HistoryEntry,
    onOpen: (HistoryEntry) -> Unit,
    onShare: (HistoryEntry) -> Unit,
    onDelete: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(false) }
    val date = remember(e.time) { SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(e.time)) }
    val kindLabel = when (e.kind) {
        "audio" -> "Audio"
        "image" -> "Foto"
        else -> "Video"
    }
    val meta = buildList {
        add(kindLabel)
        if (e.durationMs > 0) add(formatDuration(e.durationMs))
        if (e.size > 0) add(formatSize(e.size))
        add(date)
    }.joinToString(" · ")

    Row(
        Modifier.fillMaxWidth().clickable { onOpen(e) }.padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Thumb(e, Modifier.size(width = 104.dp, height = 68.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(e.title, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(meta, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            if (e.av1) {
                Text(
                    "⚠️ Formato AV1, puede ir lento. Vuelve a bajarlo.",
                    style = MaterialTheme.typography.bodySmall, color = Warn
                )
            }
        }
        Box {
            IconButton(onClick = { open = true }) { Text("⋮", fontSize = 22.sp) }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text("Abrir") }, onClick = { open = false; onOpen(e) })
                DropdownMenuItem(text = { Text("Compartir") }, onClick = { open = false; onShare(e) })
                DropdownMenuItem(text = { Text("Eliminar") }, onClick = { open = false; onDelete() })
            }
        }
    }
}

@Composable
private fun Thumb(e: HistoryEntry, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, e.uri) {
        value = withContext(Dispatchers.IO) { loadThumb(ctx, e) }
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(if (e.kind == "audio") "♪" else "▶", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Suppress("DEPRECATION")
private fun loadThumb(ctx: android.content.Context, e: HistoryEntry): Bitmap? = try {
    val uri = Uri.parse(e.uri)
    if (Build.VERSION.SDK_INT >= 29) {
        ctx.contentResolver.loadThumbnail(uri, Size(320, 200), null)
    } else {
        val id = ContentUris.parseId(uri)
        when (e.kind) {
            "video" -> MediaStore.Video.Thumbnails.getThumbnail(
                ctx.contentResolver, id, MediaStore.Video.Thumbnails.MINI_KIND, null
            )
            "image" -> MediaStore.Images.Thumbnails.getThumbnail(
                ctx.contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null
            )
            else -> null
        }
    }
} catch (_: Exception) {
    null
}

private fun formatSize(bytes: Long): String {
    val mb = bytes / 1048576.0
    return if (mb >= 1024) String.format(Locale.getDefault(), "%.1f GB", mb / 1024)
    else String.format(Locale.getDefault(), "%.1f MB", mb)
}

private fun formatDuration(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.getDefault(), "%d:%02d:%02d", h, m, s)
    else String.format(Locale.getDefault(), "%d:%02d", m, s)
}
