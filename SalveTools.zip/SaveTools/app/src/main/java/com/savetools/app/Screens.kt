@file:OptIn(ExperimentalMaterial3Api::class)

package com.savetools.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF111111)

@Composable
fun AppRoot(
    vm: DownloadViewModel,
    onLogin: (Cookies.Service) -> Unit,
    onImport: () -> Unit,
    onOpen: (HistoryEntry) -> Unit
) {
    var screen by rememberSaveable { mutableStateOf("home") }
    BackHandler(enabled = screen != "home") { screen = "home" }

    Surface(Modifier.fillMaxSize(), color = Color(0xFFFAFAFA)) {
        if (screen == "home") {
            HomeScreen(vm, onLogin, onImport) { screen = "downloads" }
        } else {
            DownloadsScreen(vm, onOpen) { screen = "home" }
        }
    }
}

@Composable
fun HomeScreen(
    vm: DownloadViewModel,
    onLogin: (Cookies.Service) -> Unit,
    onImport: () -> Unit,
    onDownloads: () -> Unit
) {
    val items by vm.items.collectAsStateWithLifecycle()
    val connected by vm.connected.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    var text by rememberSaveable { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current

    LazyColumn(
        modifier = Modifier.fillMaxSize().systemBarsPadding(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                FilledTonalButton(onClick = onDownloads) { Text("Mis descargas") }
            }
            Spacer(Modifier.height(4.dp))
            Text("Agrega links, elige calidad y descarga.", color = Color.Gray)
        }

        item {
            OutlinedCard(shape = RoundedCornerShape(28.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        label = { Text("Enlaces (uno por línea)") },
                        minLines = 3,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "TikTok, YouTube, Instagram, X, Facebook y más",
                        style = MaterialTheme.typography.bodySmall, color = Color.Gray
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilledTonalButton(
                            onClick = {
                                clipboard.getText()?.text?.let {
                                    text = if (text.isBlank()) it else text + "\n" + it
                                }
                            },
                            modifier = Modifier.weight(1f).height(52.dp)
                        ) { Text("Pegar") }
                        Button(
                            onClick = { vm.addLinks(text); text = "" },
                            colors = ButtonDefaults.buttonColors(containerColor = Ink),
                            modifier = Modifier.weight(1.4f).height(52.dp)
                        ) { Text("+  Agregar", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }

        if (items.isEmpty()) {
            item {
                Text(
                    "Pega uno o varios enlaces y toca Agregar.\nAquí aparecen para que elijas la calidad.",
                    color = Color.Gray, modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("En la lista (${items.size})", fontWeight = FontWeight.SemiBold)
                    Button(
                        onClick = vm::downloadAll,
                        colors = ButtonDefaults.buttonColors(containerColor = Ink)
                    ) { Text("Descargar todo") }
                }
            }
            items(items, key = { it.id }) { ItemCard(it, vm) }
        }

        item {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEFEFEF))
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Cuentas", style = MaterialTheme.typography.titleLarge)
                    Text("Opcional. Solo para videos que piden iniciar sesión.", color = Color.Gray)
                    Cookies.Service.values().forEach { s ->
                        val on = s.id in connected
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(s.label, fontWeight = FontWeight.Medium)
                                Text(
                                    if (on) "Conectado" else s.desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (on) Color(0xFF2EA44F) else Color.Gray
                                )
                            }
                            TextButton(onClick = { if (on) vm.disconnect(s) else onLogin(s) }) {
                                Text(if (on) "Desconectar" else "Conectar", color = Ink)
                            }
                        }
                    }
                    TextButton(onClick = onImport) {
                        Text(
                            if ("import" in connected) "cookies.txt importado (cambiar)" else "Importar cookies.txt",
                            color = Ink
                        )
                    }
                    if (notice.isNotBlank()) Text(notice, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = vm::updateEngine) {
                        Text("Actualizar motor de descarga", color = Ink)
                    }
                }
            }
        }

        item {
            Text(
                "Descarga solo contenido sobre el que tengas derecho.",
                style = MaterialTheme.typography.bodySmall, color = Color.Gray
            )
        }
    }
}

@Composable
private fun ItemCard(item: DownloadItem, vm: DownloadViewModel) {
    val busy = item.status == Status.DOWNLOADING || item.status == Status.QUEUED
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                item.title ?: item.url, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            if (item.title != null) {
                Text(
                    item.url, style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Quality.values().forEach { q ->
                    FilterChip(
                        selected = item.quality == q,
                        onClick = { vm.setQuality(item.id, q) },
                        enabled = !busy,
                        label = { Text(q.label) }
                    )
                }
            }
            if (item.status == Status.DOWNLOADING) {
                LinearProgressIndicator(progress = { item.progress }, modifier = Modifier.fillMaxWidth())
            }
            if (item.message.isNotBlank()) {
                Text(
                    item.message, style = MaterialTheme.typography.bodySmall,
                    color = if (item.status == Status.ERROR) Color(0xFFB3261E) else Color.Gray
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (busy) {
                    OutlinedButton(onClick = { vm.cancel(item.id) }) { Text("Cancelar") }
                } else {
                    Button(
                        onClick = { vm.download(item.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = Ink)
                    ) { Text(if (item.status == Status.DONE) "Descargar otra vez" else "Descargar") }
                }
                TextButton(onClick = { vm.remove(item.id) }) { Text("Quitar", color = Ink) }
            }
        }
    }
}

@Composable
fun DownloadsScreen(vm: DownloadViewModel, onOpen: (HistoryEntry) -> Unit, onBack: () -> Unit) {
    val history by vm.history.collectAsStateWithLifecycle()
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Mis descargas", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            FilledTonalButton(onClick = onBack) { Text("Volver") }
        }
        Spacer(Modifier.height(12.dp))

        if (history.isEmpty()) {
            Text("Todavía no has descargado nada.", color = Color.Gray)
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(history) { e ->
                    Card(
                        onClick = { onOpen(e) },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(e.title, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                fmt.format(Date(e.time)), style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
            TextButton(onClick = vm::clearHistory) { Text("Borrar historial", color = Ink) }
        }
    }
}
