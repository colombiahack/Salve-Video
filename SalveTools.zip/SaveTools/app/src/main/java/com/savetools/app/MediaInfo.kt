package com.savetools.app

import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import java.io.File

object MediaInfo {
    fun durationMs(file: File): Long = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(file.absolutePath)
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        r.release()
        d
    } catch (_: Exception) {
        0L
    }

    fun isAv1(file: File): Boolean = try {
        val ex = MediaExtractor()
        ex.setDataSource(file.absolutePath)
        var av1 = false
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) == "video/av01") av1 = true
        }
        ex.release()
        av1
    } catch (_: Exception) {
        false
    }
}
