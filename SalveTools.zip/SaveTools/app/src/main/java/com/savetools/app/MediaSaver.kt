package com.savetools.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File

object MediaSaver {

    data class Saved(val uri: Uri, val mime: String, val kind: String) {
        val folderLabel: String
            get() = when (kind) {
                "audio" -> "Música/SaveTools"
                "image" -> "Imágenes/SaveTools"
                else -> "Películas/SaveTools"
            }
    }

    /** Copia el archivo a Películas, Música o Imágenes dentro de la carpeta SaveTools. */
    fun save(ctx: Context, file: File): Saved? {
        val ext = file.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "mp3", "m4a", "opus", "ogg", "aac" -> "audio/mpeg"
            "jpg", "jpeg", "png", "webp" -> "image/jpeg"
            else -> "video/mp4"
        }
        val kind = when {
            mime.startsWith("audio") -> "audio"
            mime.startsWith("image") -> "image"
            else -> "video"
        }
        val collection = when (kind) {
            "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val baseDir = when (kind) {
            "audio" -> Environment.DIRECTORY_MUSIC
            "image" -> Environment.DIRECTORY_PICTURES
            else -> Environment.DIRECTORY_MOVIES
        }
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
        }

        val uri: Uri = if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, "$baseDir/SaveTools")
            values.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val u = resolver.insert(collection, values) ?: return null
            resolver.openOutputStream(u)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(u, values, null, null)
            u
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(baseDir), "SaveTools")
                .apply { mkdirs() }
            val dest = File(dir, file.name)
            file.copyTo(dest, overwrite = true)
            @Suppress("DEPRECATION")
            values.put(MediaStore.MediaColumns.DATA, dest.absolutePath)
            resolver.insert(collection, values) ?: return null
        }
        return Saved(uri, mime, kind)
    }
}
