package com.savetools.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

/** Repositorio de GitHub donde publicas los Releases con el APK. */
object UpdateConfig {
    const val OWNER = "Colombiahack"
    const val REPO = "Salve-Video"
}

class UpdateException(message: String) : Exception(message)

data class ReleaseInfo(val version: String, val apkUrl: String, val size: Long)

sealed interface UpdateState {
    object Idle : UpdateState
    object Checking : UpdateState
    data class UpToDate(val version: String) : UpdateState
    data class Downloading(
        val version: String, val progress: Float, val doneBytes: Long, val totalBytes: Long
    ) : UpdateState
    object NeedPermission : UpdateState
    object Installing : UpdateState
    data class Error(val message: String) : UpdateState
}

object Updater {

    fun currentVersion(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "0"
    } catch (e: Exception) {
        "0"
    }

    /** Compara "v1.6" contra "1.5" número por número. */
    fun isNewer(remote: String, local: String): Boolean {
        val r = Regex("\\d+").findAll(remote).map { it.value.toInt() }.toList()
        val l = Regex("\\d+").findAll(local).map { it.value.toInt() }.toList()
        for (i in 0 until maxOf(r.size, l.size)) {
            val a = r.getOrElse(i) { 0 }
            val b = l.getOrElse(i) { 0 }
            if (a != b) return a > b
        }
        return false
    }

    fun fetchLatest(): ReleaseInfo {
        val url = URL("https://api.github.com/repos/${UpdateConfig.OWNER}/${UpdateConfig.REPO}/releases/latest")
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "SaveTools-Updater")
        try {
            val code = c.responseCode
            if (code == 404) throw UpdateException("Aún no hay una versión publicada en GitHub (Releases).")
            if (code == 403) throw UpdateException("GitHub limitó las consultas. Intenta más tarde.")
            if (code != 200) throw UpdateException("GitHub respondió con el código $code.")

            val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val tag = json.optString("tag_name")
            val assets = json.optJSONArray("assets") ?: JSONArray()
            var apk: JSONObject? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) { apk = a; break }
            }
            if (apk == null) throw UpdateException("La versión $tag no tiene un archivo .apk adjunto.")
            return ReleaseInfo(tag, apk.getString("browser_download_url"), apk.optLong("size"))
        } finally {
            c.disconnect()
        }
    }

    suspend fun download(ctx: Context, info: ReleaseInfo, onProgress: (Long, Long) -> Unit): File {
        val dir = File(ctx.cacheDir, "updates").apply { deleteRecursively(); mkdirs() }
        val out = File(dir, "update.apk")
        val c = URL(info.apkUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "SaveTools-Updater")
        try {
            if (c.responseCode != 200) throw UpdateException("No se pudo descargar (código ${c.responseCode}).")
            val total = if (c.contentLengthLong > 0) c.contentLengthLong else info.size
            c.inputStream.use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var lastReport = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (done - lastReport >= 256 * 1024) {
                            lastReport = done
                            onProgress(done, total)
                        }
                    }
                    onProgress(done, if (total > 0) total else done)
                }
            }
            return out
        } catch (e: Exception) {
            out.delete()
            throw e
        } finally {
            c.disconnect()
        }
    }

    fun canInstall(ctx: Context): Boolean = ctx.packageManager.canRequestPackageInstalls()

    fun openInstallSettings(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun install(ctx: Context, file: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
