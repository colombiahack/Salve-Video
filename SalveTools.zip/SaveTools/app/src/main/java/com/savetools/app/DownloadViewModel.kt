package com.savetools.app

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

class DownloadViewModel(private val app: Application) : AndroidViewModel(app) {

    // La cola vive en DownloadCenter (sobrevive a la pantalla)
    val items: StateFlow<List<DownloadItem>> = DownloadCenter.items
    val history: StateFlow<List<HistoryEntry>> = DownloadCenter.history

    private val _connected = MutableStateFlow(computeConnected())
    val connected: StateFlow<Set<String>> = _connected.asStateFlow()

    private val _notice = MutableStateFlow("")
    val notice: StateFlow<String> = _notice.asStateFlow()

    private val themePrefs = app.getSharedPreferences("theme", Context.MODE_PRIVATE)
    private val _theme = MutableStateFlow(
        ThemeSettings(themePrefs.getInt("mode", 0), themePrefs.getInt("accent", 0))
    )
    val theme: StateFlow<ThemeSettings> = _theme.asStateFlow()

    private val _updateState = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val updateState: StateFlow<UpdateState> = _updateState.asStateFlow()
    private var updateJob: Job? = null
    private var pendingApk: File? = null

    private val settings = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _clipDetect = MutableStateFlow(settings.getBoolean("clip_detect", true))
    val clipDetect: StateFlow<Boolean> = _clipDetect.asStateFlow()
    private val _clipLink = MutableStateFlow<String?>(null)
    val clipLink: StateFlow<String?> = _clipLink.asStateFlow()

    init {
        File(app.cacheDir, "updates").deleteRecursively()
        autoUpdateEngine()
    }

    // ---------- Cola (delegada) ----------
    fun addLinks(text: String) { DownloadCenter.addLinks(text) }
    fun setQuality(id: Long, q: Quality) = DownloadCenter.setQuality(id, q)
    fun remove(id: Long) = DownloadCenter.remove(id)
    fun download(id: Long) = DownloadCenter.download(id)
    fun cancel(id: Long) = DownloadCenter.cancel(id)
    fun toggleSelected(id: Long) = DownloadCenter.toggleSelected(id)
    fun selectAll(sel: Boolean) = DownloadCenter.selectAll(sel)
    fun toggleSelectAll() = DownloadCenter.toggleSelectAll()
    fun setQualityForSelected(q: Quality) = DownloadCenter.setQualityForSelected(q)
    fun downloadSelected() = DownloadCenter.downloadSelected()
    fun resumeInterrupted() = DownloadCenter.resumeInterrupted()
    fun refreshHistory() = DownloadCenter.refreshHistory()
    fun deleteEntry(e: HistoryEntry) = DownloadCenter.deleteEntry(e)
    fun clearHistory() = DownloadCenter.clearHistory()

    // ---------- Portapapeles ----------
    fun setClipDetect(on: Boolean) {
        settings.edit().putBoolean("clip_detect", on).apply()
        _clipDetect.value = on
        if (!on) _clipLink.value = null
    }

    /** Se llama cuando la app recupera el foco (Android solo deja leer el portapapeles así). */
    fun checkClipboard() {
        if (!_clipDetect.value) return
        val cm = app.getSystemService(ClipboardManager::class.java) ?: return
        val text = (try {
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(app)?.toString()
        } catch (e: Exception) {
            null
        }) ?: return
        val link = Regex("https?://\\S+").find(text)?.value?.trimEnd(',', ')', '.') ?: return
        if (link == settings.getString("last_clip", "")) return
        if (DownloadCenter.items.value.any { it.url == link }) return
        _clipLink.value = link
    }

    fun acceptClip() {
        val link = _clipLink.value ?: return
        settings.edit().putString("last_clip", link).apply()
        _clipLink.value = null
        DownloadCenter.addLinks(link)
    }

    fun dismissClip() {
        _clipLink.value?.let { settings.edit().putString("last_clip", it).apply() }
        _clipLink.value = null
    }

    // ---------- Apariencia ----------
    fun setThemeMode(mode: Int) {
        themePrefs.edit().putInt("mode", mode).apply()
        _theme.update { it.copy(mode = mode) }
    }

    fun setAccent(index: Int) {
        themePrefs.edit().putInt("accent", index).apply()
        _theme.update { it.copy(accent = index) }
    }

    // ---------- Cuentas ----------
    private fun computeConnected(): Set<String> {
        val set = Cookies.Service.values().filter { Cookies.file(app, it.id).exists() }.map { it.id }.toMutableSet()
        if (Cookies.importFile(app).exists()) set.add("import")
        return set
    }

    fun refreshAccounts() { _connected.value = computeConnected() }

    fun disconnect(s: Cookies.Service) {
        Cookies.file(app, s.id).delete()
        try { CookieManager.getInstance().removeAllCookies(null) } catch (_: Exception) {}
        refreshAccounts()
        _notice.value = "${s.label} desconectado"
    }

    fun importCookies(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                app.contentResolver.openInputStream(uri)?.use { input ->
                    Cookies.importFile(app).outputStream().use { input.copyTo(it) }
                }
                refreshAccounts()
                _notice.value = "cookies.txt importado"
            } catch (e: Exception) {
                _notice.value = "No se pudo importar: ${e.message?.take(100)}"
            }
        }
    }

    // ---------- Actualización de la app ----------
    fun checkForUpdate() {
        updateJob?.cancel()
        updateJob = viewModelScope.launch(Dispatchers.IO) {
            _updateState.value = UpdateState.Checking
            try {
                val info = Updater.fetchLatest()
                val current = Updater.currentVersion(app)
                if (!Updater.isNewer(info.version, current)) {
                    _updateState.value = UpdateState.UpToDate(current)
                    return@launch
                }
                _updateState.value = UpdateState.Downloading(info.version, 0f, 0L, info.size)
                val file = Updater.download(app, info) { done, total ->
                    val pr = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
                    _updateState.value = UpdateState.Downloading(info.version, pr, done, total)
                }
                pendingApk = file
                installPending()
            } catch (e: CancellationException) {
                throw e
            } catch (e: UpdateException) {
                _updateState.value = UpdateState.Error(e.message ?: "Error")
            } catch (e: Exception) {
                _updateState.value = UpdateState.Error("Revisa tu conexión e inténtalo de nuevo.")
            }
        }
    }

    fun installPending() {
        val file = pendingApk ?: return
        if (!Updater.canInstall(app)) {
            _updateState.value = UpdateState.NeedPermission
            return
        }
        try {
            Updater.install(app, file)
            _updateState.value = UpdateState.Installing
        } catch (e: Exception) {
            _updateState.value = UpdateState.Error("No se pudo abrir el instalador.")
        }
    }

    fun openInstallSettings() {
        try { Updater.openInstallSettings(app) } catch (_: Exception) {}
    }

    fun cancelUpdate() {
        updateJob?.cancel()
        _updateState.value = UpdateState.Idle
    }

    fun dismissUpdate() {
        _updateState.value = UpdateState.Idle
    }

    // ---------- Motor yt-dlp ----------
    fun updateEngine() {
        viewModelScope.launch(Dispatchers.IO) {
            _notice.value = "Actualizando motor…"
            try {
                val r = YoutubeDL.getInstance().updateYoutubeDL(app)
                _notice.value = "Motor actualizado: $r"
            } catch (e: Exception) {
                _notice.value = "Error al actualizar: ${e.message?.take(120)}"
            }
        }
    }

    /** Una vez al día actualiza yt-dlp en segundo plano. */
    private fun autoUpdateEngine() {
        val prefs = app.getSharedPreferences("engine", Context.MODE_PRIVATE)
        val last = prefs.getLong("last_update", 0L)
        if (System.currentTimeMillis() - last < 24L * 3600 * 1000) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(app)
                prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
            } catch (_: Exception) {
            }
        }
    }
}
