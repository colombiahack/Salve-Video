package com.savetools.app

import android.app.Application
import android.net.Uri
import android.webkit.CookieManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

class DownloadViewModel(private val app: Application) : AndroidViewModel(app) {

    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private val _history = MutableStateFlow(History.load(app))
    val history: StateFlow<List<HistoryEntry>> = _history.asStateFlow()

    private val _connected = MutableStateFlow(computeConnected())
    val connected: StateFlow<Set<String>> = _connected.asStateFlow()

    private val _notice = MutableStateFlow("")
    val notice: StateFlow<String> = _notice.asStateFlow()

    private val mutex = Mutex()                       // una descarga a la vez
    private val jobs = mutableMapOf<Long, Job>()
    private val cancelled = mutableSetOf<Long>()
    private var nextId = 1L

    private fun update(id: Long, f: (DownloadItem) -> DownloadItem) =
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }

    // ---------- Enlaces ----------
    fun addLinks(text: String) {
        val links = Regex("https?://\\S+").findAll(text)
            .map { it.value.trimEnd(',', ')', '.') }.distinct().toList()
        val existing = _items.value.map { it.url }.toSet()
        val fresh = links.filter { it !in existing }.map { DownloadItem(id = nextId++, url = it) }
        if (fresh.isEmpty()) return
        _items.update { fresh + it }
        fresh.forEach { fetchTitle(it) }
    }

    private fun fetchTitle(item: DownloadItem) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val req = YoutubeDLRequest(item.url).apply {
                    addOption("--no-playlist")
                    applyCookies(this, item.url)
                }
                val info = YoutubeDL.getInstance().getInfo(req)
                update(item.id) { it.copy(title = info.title) }
            } catch (_: Exception) {
            }
        }
    }

    fun setQuality(id: Long, q: Quality) = update(id) { it.copy(quality = q) }

    fun remove(id: Long) {
        cancel(id)
        _items.update { l -> l.filter { it.id != id } }
    }

    // ---------- Descarga ----------
    fun download(id: Long) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        if (item.status == Status.DOWNLOADING || item.status == Status.QUEUED) return
        cancelled.remove(id)
        update(id) { it.copy(status = Status.QUEUED, progress = 0f, message = "En cola") }
        jobs[id] = viewModelScope.launch(Dispatchers.IO) {
            mutex.withLock { runDownload(id) }
        }
    }

    fun downloadAll() {
        _items.value.filter { it.status == Status.READY || it.status == Status.ERROR }
            .forEach { download(it.id) }
    }

    fun cancel(id: Long) {
        cancelled.add(id)
        try { YoutubeDL.getInstance().destroyProcessById("dl-$id") } catch (_: Exception) {}
        jobs.remove(id)?.cancel()
        update(id) {
            if (it.status == Status.DOWNLOADING || it.status == Status.QUEUED)
                it.copy(status = Status.READY, progress = 0f, message = "Cancelado")
            else it
        }
    }

    private fun runDownload(id: Long) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        update(id) { it.copy(status = Status.DOWNLOADING, message = "Descargando…") }
        val tmp = File(app.cacheDir, "dl/$id").apply { deleteRecursively(); mkdirs() }
        try {
            val req = YoutubeDLRequest(item.url).apply {
                addOption("--no-playlist")
                addOption("-o", "${tmp.absolutePath}/%(title).100s.%(ext)s")
                applyFormat(this, item.quality)
                applyCookies(this, item.url)
            }
            YoutubeDL.getInstance().execute(req, "dl-$id") { p, _, _ ->
                update(id) { it.copy(progress = (p / 100f).coerceIn(0f, 1f)) }
            }

            val file = tmp.listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.length() }
            if (file == null) {
                update(id) { it.copy(status = Status.ERROR, message = "No se generó ningún archivo") }
                return
            }
            update(id) { it.copy(message = "Guardando…") }
            val saved = MediaSaver.save(app, file)
            if (saved == null) {
                update(id) { it.copy(status = Status.ERROR, message = "No se pudo guardar el archivo") }
            } else {
                History.add(app, HistoryEntry(file.nameWithoutExtension, saved.uri.toString(), saved.mime, System.currentTimeMillis()))
                _history.value = History.load(app)
                val where = if (saved.isAudio) "Música/SaveTools" else "Películas/SaveTools"
                update(id) { it.copy(status = Status.DONE, progress = 1f, message = "Guardado en $where") }
            }
        } catch (e: Exception) {
            if (id in cancelled) {
                cancelled.remove(id)
            } else {
                val msg = e.message?.lineSequence()?.lastOrNull { it.isNotBlank() }?.take(160) ?: "Error"
                update(id) { it.copy(status = Status.ERROR, message = msg) }
            }
        } finally {
            tmp.deleteRecursively()
            jobs.remove(id)
        }
    }

    private fun applyFormat(r: YoutubeDLRequest, q: Quality) {
        when (q) {
            Quality.AUDIO -> {
                r.addOption("-f", "bestaudio/best")
                r.addOption("-x")
                r.addOption("--audio-format", "mp3")
            }
            Quality.BEST -> {
                r.addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b")
                r.addOption("--merge-output-format", "mp4")
            }
            else -> {
                val h = q.height
                r.addOption("-f", "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/b[height<=$h][ext=mp4]/b[height<=$h]/b")
                r.addOption("--merge-output-format", "mp4")
            }
        }
    }

    private fun applyCookies(r: YoutubeDLRequest, url: String) {
        Cookies.forUrl(app, url)?.let { r.addOption("--cookies", it.absolutePath) }
    }

    // ---------- Cuentas ----------
    private fun computeConnected(): Set<String> {
        val set = Cookies.Service.values().filter { Cookies.file(app, it.id).exists() }.map { it.id }.toMutableSet()
        if (Cookies.importFile(app).exists()) set.add("import")
        return set
    }

    fun refreshAccounts() { _connected.value = computeConnected() }

    fun disconnect(s: Cookies.Service) {
        Cookies.file(app, s.id).delete()
        try { CookieManager.getInstance().removeAllCookies(null) } catch (_: Exception) {}
        refreshAccounts()
        _notice.value = "${s.label} desconectado"
    }

    fun importCookies(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                app.contentResolver.openInputStream(uri)?.use { input ->
                    Cookies.importFile(app).outputStream().use { input.copyTo(it) }
                }
                refreshAccounts()
                _notice.value = "cookies.txt importado"
            } catch (e: Exception) {
                _notice.value = "No se pudo importar: ${e.message?.take(100)}"
            }
        }
    }

    fun clearHistory() {
        History.clear(app)
        _history.value = emptyList()
    }

    fun updateEngine() {
        viewModelScope.launch(Dispatchers.IO) {
            _notice.value = "Actualizando motor…"
            try {
                val r = YoutubeDL.getInstance().updateYoutubeDL(app)
                _notice.value = "Motor actualizado: $r"
            } catch (e: Exception) {
                _notice.value = "Error al actualizar: ${e.message?.take(120)}"
            }
        }
    }
}
