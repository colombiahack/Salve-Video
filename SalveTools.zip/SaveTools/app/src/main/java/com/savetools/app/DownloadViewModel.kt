package com.savetools.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class UiState(
    val url: String = "",
    val progress: Float = 0f,
    val status: String = "Pega un enlace o compártelo desde otra app",
    val busy: Boolean = false
)

class DownloadViewModel(private val app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null
    private val processId = "savetools-download"

    fun setUrl(url: String) = _state.update { it.copy(url = url) }

    fun download() {
        val url = _state.value.url.trim()
        if (url.isEmpty() || _state.value.busy) return

        job = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, progress = 0f, status = "Descargando…") }
            val tmp = File(app.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
            try {
                val request = YoutubeDLRequest(url).apply {
                    addOption("--no-playlist")
                    addOption("-o", "${tmp.absolutePath}/%(title).100s.%(ext)s")
                    addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b")
                    addOption("--merge-output-format", "mp4")
                }
                YoutubeDL.getInstance().execute(request, processId) { progress, _, _ ->
                    _state.update { it.copy(progress = (progress / 100f).coerceIn(0f, 1f)) }
                }

                val file = tmp.listFiles()?.maxByOrNull { it.lastModified() }
                if (file == null) {
                    _state.update { it.copy(status = "No se generó ningún archivo") }
                } else {
                    _state.update { it.copy(status = "Guardando en la galería…") }
                    val uri = MediaSaver.saveVideo(app, file)
                    _state.update {
                        it.copy(
                            progress = 1f,
                            status = if (uri != null) "Listo: Películas/SaveTools"
                            else "No se pudo guardar el archivo"
                        )
                    }
                }
            } catch (e: Exception) {
                _state.update { it.copy(status = "Error: ${e.message?.take(200)}") }
            } finally {
                tmp.deleteRecursively()
                _state.update { it.copy(busy = false) }
            }
        }
    }

    fun cancel() {
        YoutubeDL.getInstance().destroyProcessById(processId)
        job?.cancel()
        _state.update { it.copy(busy = false, status = "Cancelado") }
    }

    /** Actualiza yt-dlp: los sitios cambian a menudo. */
    fun updateEngine() {
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(status = "Actualizando motor…") }
            try {
                val result = YoutubeDL.getInstance().updateYoutubeDL(app)
                _state.update { it.copy(status = "Motor actualizado: $result") }
            } catch (e: Exception) {
                _state.update { it.copy(status = "Error al actualizar: ${e.message?.take(200)}") }
            }
        }
    }
}
