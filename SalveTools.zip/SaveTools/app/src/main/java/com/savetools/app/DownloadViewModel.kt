package com.savetools.app

import android.app.Application
import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

class DownloadViewModel(private val app: Application) : AndroidViewModel(app) {

    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private val _history = MutableStateFlow(History.load(app))
    val history: StateFlow<List<HistoryEntry>> = _history.asStateFlow()

    private val _connected = MutableStateFlow(computeConnected())
    val connected: StateFlow<Set<String>> = _connected.asStateFlow()

    private val _notice = MutableStateFlow("")
    val notice: StateFlow<String> = _notice.asStateFlow()

    private val themePrefs = app.getSharedPreferences("theme", Context.MODE_PRIVATE)
    private val _theme = MutableStateFlow(
        ThemeSettings(themePrefs.getInt("mode", 0), themePrefs.getInt("accent", 0))
    )
    val theme: StateFlow<ThemeSettings> = _theme.asStateFlow()

    private val mutex = Mutex()                       // una descarga a la vez
    private val jobs = mutableMapOf<Long, Job>()
    private val cancelled = mutableSetOf<Long>()
    private var nextId = 1L

    init {
        autoUpdateEngine()
    }

    private fun update(id: Long, f: (DownloadItem) -> DownloadItem) =
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }

    // ---------- Apariencia ----------
    fun setThemeMode(mode: Int) {
        themePrefs.edit().putInt("mode", mode).apply()
        _theme.update { it.copy(mode = mode) }
    }

    fun setAccent(index: Int) {
        themePrefs.edit().putInt("accent", index).apply()
        _theme.update { it.copy(accent = index) }
    }

    // ---------- Enlaces ----------
    fun addLinks(text: String) {
        val links = Regex("https?://\\S+").findAll(text)
            .map { it.value.trimEnd(',', ')', '.') }.distinct().toList()
        val existing = _items.value.map { it.url }.toSet()
        val fresh = links.filter { it !in existing }.map { DownloadItem(id = nextId++, url = it) }
        if (fresh.isEmpty()) return
        _items.update { fresh + it }
        fresh.forEach { fetchInfo(it) }
    }

    /** Lee título, miniatura, duración y resolución máxima sin descargar nada. */
    private fun fetchInfo(item: DownloadItem) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val req = YoutubeDLRequest(item.url).apply {
                    addOption("--no-playlist")
                    addOption("--print", "%(title)s|||%(duration)s|||%(thumbnail)s|||%(height)s")
                    applyCookies(this, item.url)
                }
                val out = YoutubeDL.getInstance().execute(req).out
                val line = out.lineSequence().firstOrNull { it.contains("|||") } ?: return@launch
                val p = line.split("|||")
                fun v(i: Int) = p.getOrNull(i)?.trim()?.takeIf { it.isNotEmpty() && it != "NA" && it != "None" }
                update(item.id) {
                    it.copy(
                        title = v(0),
                        durationSec = v(1)?.toDoubleOrNull()?.toInt(),
                        thumbnail = v(2),
                        maxHeight = v(3)?.toDoubleOrNull()?.toInt()
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    fun setQuality(id: Long, q: Quality) = update(id) { it.copy(quality = q) }

    fun remove(id: Long) {
        cancel(id)
        _items.update { l -> l.filter { it.id != id } }
    }

    // ---------- Descarga ----------
    fun download(id: Long) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        if (item.status == Status.DOWNLOADING || item.status == Status.QUEUED) return
        cancelled.remove(id)
        update(id) { it.copy(status = Status.QUEUED, progress = 0f, message = "En cola") }
        jobs[id] = viewModelScope.launch(Dispatchers.IO) {
            mutex.withLock { runDownload(id) }
        }
    }

    fun toggleSelected(id: Long) = update(id) { it.copy(selected = !it.selected) }

    fun selectAll(sel: Boolean) = _items.update { l -> l.map { it.copy(selected = sel) } }

    fun toggleSelectAll() = selectAll(!_items.value.all { it.selected })

    fun setQualityForSelected(q: Quality) = _items.update { l ->
        l.map {
            val busy = it.status == Status.DOWNLOADING || it.status == Status.QUEUED
            if (it.selected && !busy) it.copy(quality = q) else it
        }
    }

    fun downloadSelected() {
        _items.value.filter { it.selected && (it.status == Status.READY || it.status == Status.ERROR) }
            .forEach { download(it.id) }
    }

    fun cancel(id: Long) {
        cancelled.add(id)
        try { YoutubeDL.getInstance().destroyProcessById("dl-$id") } catch (_: Exception) {}
        jobs.remove(id)?.cancel()
        update(id) {
            if (it.status == Status.DOWNLOADING || it.status == Status.QUEUED)
                it.copy(status = Status.READY, progress = 0f, message = "Cancelado")
            else it
        }
    }

    private fun runDownload(id: Long) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        update(id) { it.copy(status = Status.DOWNLOADING, message = "Descargando…") }
        val tmp = File(app.cacheDir, "dl/$id").apply { deleteRecursively(); mkdirs() }
        try {
            val req = YoutubeDLRequest(item.url).apply {
                addOption("--no-playlist")
                addOption("-o", "${tmp.absolutePath}/%(title).100s.%(ext)s")
                applyFormat(this, item.quality)
                applyCookies(this, item.url)
            }
            YoutubeDL.getInstance().execute(req, "dl-$id") { p, _, _ ->
                update(id) { it.copy(progress = (p / 100f).coerceIn(0f, 1f)) }
            }

            val file = tmp.listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.length() }
            if (file == null) {
                update(id) { it.copy(status = Status.ERROR, message = "No se generó ningún archivo") }
                return
            }
            update(id) { it.copy(message = "Guardando…") }

            val size = file.length()
            val saved = MediaSaver.save(app, file)
            if (saved == null) {
                update(id) { it.copy(status = Status.ERROR, message = "No se pudo guardar el archivo") }
            } else {
                val duration = if (saved.kind != "image") MediaInfo.durationMs(file) else 0L
                val av1 = saved.kind == "video" && MediaInfo.isAv1(file)
                History.add(
                    app,
                    HistoryEntry(
                        file.nameWithoutExtension, saved.uri.toString(), saved.mime,
                        System.currentTimeMillis(), size, duration, av1
                    )
                )
                _history.value = History.load(app)
                update(id) { it.copy(status = Status.DONE, progress = 1f, selected = false, message = "Guardado en ${saved.folderLabel}") }
            }
        } catch (e: Exception) {
            if (id in cancelled) {
                cancelled.remove(id)
            } else {
                val msg = e.message?.lineSequence()?.lastOrNull { it.isNotBlank() }?.take(160) ?: "Error"
                update(id) { it.copy(status = Status.ERROR, message = msg) }
            }
        } finally {
            tmp.deleteRecursively()
            jobs.remove(id)
        }
    }

    /** "Mejor" = mayor resolución; a igual resolución prefiere H.264 (evita AV1 lento). */
    private fun applyFormat(r: YoutubeDLRequest, q: Quality) {
        when (q) {
            Quality.AUDIO -> {
                r.addOption("-f", "bestaudio/best")
                r.addOption("-x")
                r.addOption("--audio-format", "mp3")
            }
            Quality.BEST -> {
                r.addOption("-f", "bv*+ba/b")
                r.addOption("-S", "res,vcodec:h264,acodec:m4a")
                r.addOption("--merge-output-format", "mp4")
            }
            else -> {
                val h = q.height
                r.addOption("-f", "bv*+ba/b")
                r.addOption("-S", "res:$h,vcodec:h264,acodec:m4a")
                r.addOption("--merge-output-format", "mp4")
            }
        }
    }

    private fun applyCookies(r: YoutubeDLRequest, url: String) {
        Cookies.forUrl(app, url)?.let { r.addOption("--cookies", it.absolutePath) }
    }

    // ---------- Historial ----------
    fun refreshHistory() {
        viewModelScope.launch(Dispatchers.IO) { _history.value = History.prune(app) }
    }

    fun deleteEntry(e: HistoryEntry) {
        viewModelScope.launch(Dispatchers.IO) {
            try { app.contentResolver.delete(Uri.parse(e.uri), null, null) } catch (_: Exception) {}
            History.remove(app, e.uri)
            _history.value = History.load(app)
        }
    }

    fun clearHistory() {
        History.clear(app)
        _history.value = emptyList()
    }

    // ---------- Cuentas ----------
    private fun computeConnected(): Set<String> {
        val set = Cookies.Service.values().filter { Cookies.file(app, it.id).exists() }.map { it.id }.toMutableSet()
        if (Cookies.importFile(app).exists()) set.add("import")
        return set
    }

    fun refreshAccounts() { _connected.value = computeConnected() }

    fun disconnect(s: Cookies.Service) {
        Cookies.file(app, s.id).delete()
        try { CookieManager.getInstance().removeAllCookies(null) } catch (_: Exception) {}
        refreshAccounts()
        _notice.value = "${s.label} desconectado"
    }

    fun importCookies(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                app.contentResolver.openInputStream(uri)?.use { input ->
                    Cookies.importFile(app).outputStream().use { input.copyTo(it) }
                }
                refreshAccounts()
                _notice.value = "cookies.txt importado"
            } catch (e: Exception) {
                _notice.value = "No se pudo importar: ${e.message?.take(100)}"
            }
        }
    }

    // ---------- Motor yt-dlp ----------
    fun updateEngine() {
        viewModelScope.launch(Dispatchers.IO) {
            _notice.value = "Actualizando motor…"
            try {
                val r = YoutubeDL.getInstance().updateYoutubeDL(app)
                _notice.value = "Motor actualizado: $r"
            } catch (e: Exception) {
                _notice.value = "Error al actualizar: ${e.message?.take(120)}"
            }
        }
    }

    /** Una vez al día actualiza yt-dlp en segundo plano. */
    private fun autoUpdateEngine() {
        val prefs = app.getSharedPreferences("engine", Context.MODE_PRIVATE)
        val last = prefs.getLong("last_update", 0L)
        if (System.currentTimeMillis() - last < 24L * 3600 * 1000) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(app)
                prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
            } catch (_: Exception) {
            }
        }
    }
}
