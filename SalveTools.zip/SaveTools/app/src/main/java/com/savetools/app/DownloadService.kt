package com.savetools.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** Mantiene vivas las descargas con la app cerrada y muestra su progreso en una notificación. */
class DownloadService : Service() {

    companion object {
        const val ACTION_CANCEL_ALL = "com.savetools.app.CANCEL_ALL"
        private const val CHANNEL = "downloads"
        private const val ID_ONGOING = 1001
        private const val ID_DONE = 1002
    }

    private data class Summary(
        val active: Int, val title: String, val pct: Int,
        val errors: Int, val waiting: Int, val done: Int
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var sawActive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Descargas", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL_ALL) DownloadCenter.cancelAll()

        ServiceCompat.startForeground(
            this, ID_ONGOING, ongoing(summarize(DownloadCenter.items.value)),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )

        if (job == null) {
            job = scope.launch {
                DownloadCenter.items.map { summarize(it) }.distinctUntilChanged().collect { s ->
                    if (s.active > 0) {
                        sawActive = true
                        getSystemService(NotificationManager::class.java).notify(ID_ONGOING, ongoing(s))
                    } else {
                        finish(s)
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun summarize(list: List<DownloadItem>): Summary {
        val active = list.count { it.status == Status.DOWNLOADING || it.status == Status.QUEUED }
        val cur = list.firstOrNull { it.status == Status.DOWNLOADING }
            ?: list.firstOrNull { it.status == Status.QUEUED }
        return Summary(
            active = active,
            title = cur?.title ?: cur?.url ?: "",
            pct = ((cur?.progress ?: 0f) * 100).toInt(),
            errors = list.count { it.status == Status.ERROR },
            waiting = list.count { it.status == Status.WAITING },
            done = list.count { it.status == Status.DONE }
        )
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun ongoing(s: Summary) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.stat_sys_download)
        .setContentTitle(if (s.active > 1) "Descargando (${s.active} en lista)" else "Descargando")
        .setContentText(s.title)
        .setProgress(100, s.pct, s.pct == 0)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setContentIntent(openAppIntent())
        .addAction(
            0, "Cancelar",
            PendingIntent.getService(
                this, 1,
                Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL_ALL),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        .build()

    private fun finish(s: Summary) {
        job?.cancel()
        job = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (sawActive) {
            val text = when {
                s.errors > 0 -> "Algunas descargas fallaron."
                s.waiting > 0 -> "En pausa. Se reanudará al volver la conexión."
                s.done > 0 -> "Descarga completa."
                else -> null
            }
            if (text != null) {
                getSystemService(NotificationManager::class.java).notify(
                    ID_DONE,
                    NotificationCompat.Builder(this, CHANNEL)
                        .setSmallIcon(android.R.drawable.stat_sys_download_done)
                        .setContentTitle(getString(R.string.app_name))
                        .setContentText(text)
                        .setAutoCancel(true)
                        .setContentIntent(openAppIntent())
                        .build()
                )
            }
        }
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
