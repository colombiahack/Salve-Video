package com.savetools.app

enum class Quality(val label: String, val height: Int?) {
    BEST("Mejor", null),
    P1080("1080p", 1080),
    P720("720p", 720),
    P480("480p", 480),
    P360("360p", 360),
    AUDIO("Audio MP3", null)
}

enum class Status { READY, QUEUED, DOWNLOADING, DONE, ERROR }

data class DownloadItem(
    val id: Long,
    val url: String,
    val title: String? = null,
    val quality: Quality = Quality.BEST,
    val progress: Float = 0f,
    val status: Status = Status.READY,
    val message: String = ""
)
