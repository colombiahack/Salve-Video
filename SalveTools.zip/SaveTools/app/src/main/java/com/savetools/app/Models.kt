package com.savetools.app

import android.net.Uri

enum class Quality(val label: String, val height: Int?) {
    BEST("Mejor", null),
    P1080("1080p", 1080),
    P720("720p", 720),
    P480("480p", 480),
    P360("360p", 360),
    AUDIO("Audio MP3", null)
}

enum class Status { READY, QUEUED, DOWNLOADING, DONE, ERROR }

data class DownloadItem(
    val id: Long,
    val url: String,
    val title: String? = null,
    val thumbnail: String? = null,
    val durationSec: Int? = null,
    val maxHeight: Int? = null,
    val quality: Quality = Quality.BEST,
    val selected: Boolean = true,
    val progress: Float = 0f,
    val status: Status = Status.READY,
    val message: String = ""
) {
    val source: String get() = sourceName(url)
}

fun heightLabel(h: Int): String = when {
    h >= 2160 -> "4K"
    h >= 1440 -> "2K"
    else -> "${h}p"
}

/** "Mejor (2K)" cuando se conoce la resolución máxima del video. */
fun Quality.display(maxH: Int?): String =
    if (this == Quality.BEST && maxH != null && maxH > 0) "Mejor (${heightLabel(maxH)})" else label

/** Solo ofrece resoluciones menores a la máxima disponible. */
fun qualityOptions(maxH: Int?): List<Quality> = Quality.values().filter { q ->
    val h = q.height
    h == null || maxH == null || maxH <= 0 || h < maxH
}

fun sourceName(url: String): String {
    val host = Uri.parse(url).host?.lowercase()?.removePrefix("www.")?.removePrefix("m.") ?: return ""
    return when {
        host.endsWith("facebook.com") || host == "fb.watch" -> "Facebook"
        host.endsWith("youtube.com") || host == "youtu.be" -> "YouTube"
        host.endsWith("tiktok.com") -> "TikTok"
        host.endsWith("instagram.com") -> "Instagram"
        host == "x.com" || host.endsWith("twitter.com") -> "X"
        else -> host
    }
}
