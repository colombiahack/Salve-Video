package com.savetools.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {

    private val vm: DownloadViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val loginLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            vm.refreshAccounts()
        }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) vm.importCookies(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        handleIntent(intent)

        setContent {
            AppRoot(
                vm = vm,
                onLogin = { s ->
                    loginLauncher.launch(
                        Intent(this, LoginActivity::class.java).putExtra("service", s.id)
                    )
                },
                onImport = { importLauncher.launch(arrayOf("*/*")) },
                onOpen = { openEntry(it) },
                onShare = { shareEntry(it) }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Enlaces recibidos desde "Compartir": se agregan a la lista para elegir calidad. */
    private fun handleIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        intent.getStringExtra(Intent.EXTRA_TEXT)?.let { vm.addLinks(it) }
    }

    private fun openEntry(e: HistoryEntry) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse(e.uri), e.mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (ex: Exception) {
            Toast.makeText(this, "No hay app para abrir este archivo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareEntry(e: HistoryEntry) {
        try {
            val send = Intent(Intent.ACTION_SEND)
                .setType(e.mime)
                .putExtra(Intent.EXTRA_STREAM, Uri.parse(e.uri))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Compartir"))
        } catch (ex: Exception) {
            Toast.makeText(this, "No se pudo compartir", Toast.LENGTH_SHORT).show()
        }
    }
}
