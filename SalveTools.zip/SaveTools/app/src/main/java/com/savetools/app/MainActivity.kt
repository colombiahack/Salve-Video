package com.savetools.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {

    private val vm: DownloadViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT < 29 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        handleIntent(intent)

        setContent {
            MaterialTheme { Screen(vm) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Recibe el enlace desde el menú "Compartir" y empieza a descargar. */
    private fun handleIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        Regex("https?://\\S+").find(text)?.value?.let {
            vm.setUrl(it)
            vm.download()
        }
    }
}

@Composable
fun Screen(vm: DownloadViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("SaveTools", style = MaterialTheme.typography.headlineMedium)

            OutlinedTextField(
                value = state.url,
                onValueChange = vm::setUrl,
                label = { Text("Enlace del video") },
                singleLine = true,
                enabled = !state.busy,
                modifier = Modifier.fillMaxWidth()
            )

            if (state.busy) {
                Button(onClick = vm::cancel, modifier = Modifier.fillMaxWidth()) {
                    Text("Cancelar")
                }
            } else {
                Button(
                    onClick = vm::download,
                    enabled = state.url.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Descargar") }
            }

            LinearProgressIndicator(
                progress = { state.progress },
                modifier = Modifier.fillMaxWidth()
            )

            Text(state.status, style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.weight(1f))

            TextButton(onClick = vm::updateEngine, enabled = !state.busy) {
                Text("Actualizar motor de descarga")
            }
            Text(
                "Descarga solo contenido sobre el que tengas derecho.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
