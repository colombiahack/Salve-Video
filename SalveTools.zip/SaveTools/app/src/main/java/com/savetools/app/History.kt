package com.savetools.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val title: String, val uri: String, val mime: String, val time: Long)

object History {
    private const val PREFS = "history"
    private const val KEY = "entries"

    fun load(ctx: Context): List<HistoryEntry> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryEntry(o.getString("title"), o.getString("uri"), o.getString("mime"), o.getLong("time"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(ctx: Context, e: HistoryEntry) = save(ctx, (listOf(e) + load(ctx)).take(200))

    fun clear(ctx: Context) = save(ctx, emptyList())

    private fun save(ctx: Context, list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("title", it.title).put("uri", it.uri)
                    .put("mime", it.mime).put("time", it.time)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
