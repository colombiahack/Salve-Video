package com.savetools.app

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(
    val title: String,
    val uri: String,
    val mime: String,
    val time: Long,
    val size: Long = 0,
    val durationMs: Long = 0,
    val av1: Boolean = false
) {
    val kind: String
        get() = when {
            mime.startsWith("audio") -> "audio"
            mime.startsWith("image") -> "image"
            else -> "video"
        }
}

object History {
    private const val PREFS = "history"
    private const val KEY = "entries"

    fun load(ctx: Context): List<HistoryEntry> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryEntry(
                    o.getString("title"), o.getString("uri"), o.getString("mime"), o.getLong("time"),
                    o.optLong("size", 0), o.optLong("duration", 0), o.optBoolean("av1", false)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(ctx: Context, e: HistoryEntry) = save(ctx, (listOf(e) + load(ctx)).take(200))

    fun remove(ctx: Context, uri: String) = save(ctx, load(ctx).filter { it.uri != uri })

    fun clear(ctx: Context) = save(ctx, emptyList())

    /** Quita del historial los archivos que ya no existen. */
    fun prune(ctx: Context): List<HistoryEntry> {
        val all = load(ctx)
        val alive = all.filter { exists(ctx, it.uri) }
        if (alive.size != all.size) save(ctx, alive)
        return alive
    }

    private fun exists(ctx: Context, uri: String): Boolean = try {
        ctx.contentResolver.query(
            Uri.parse(uri), arrayOf(MediaStore.MediaColumns._ID), null, null, null
        )?.use { it.count > 0 } ?: false
    } catch (e: Exception) {
        false
    }

    private fun save(ctx: Context, list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("title", it.title).put("uri", it.uri).put("mime", it.mime)
                    .put("time", it.time).put("size", it.size)
                    .put("duration", it.durationMs).put("av1", it.av1)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
